Splunk.Module.FeedbackLinks = $.klass(Splunk.Module, {
    
});
